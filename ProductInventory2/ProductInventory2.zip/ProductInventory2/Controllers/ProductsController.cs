﻿namespace ProductInventory2
{
    public class ProductsController
    {
    }
}
