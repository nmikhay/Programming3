﻿namespace ProductInventory2
{
    public class Startup
    {
    }
}
