﻿namespace BookSharingPlatform.Pages
{
    public class AddBookModel
    {
    }
}
