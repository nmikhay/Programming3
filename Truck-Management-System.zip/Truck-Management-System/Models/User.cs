﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TMS_APP.Models
{
    public class User
    {
        public int Id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        [Required]
        public string email { get; set; }
        public string password { get; set; }
        public string phone { get; set; }
        [NotMapped]
        public DateOnly dateOfBirth { get; set; }
        public Roles role { get; set; }
        public enum Roles { Admin, Dispacther, Driver }

    }
}
