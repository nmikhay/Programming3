﻿namespace TMS_APP.Constants
{
    public enum UserStatus
    {
        Active,
        Inactive,
        Suspended
    }
}
