﻿namespace TMS_APP.Constants
{
    public class UserStatusD
    {
        public const string Status_Active = "Active";
        public const string Status_Inactive = "Inactive";
        public const string Status_Locked = "Locked";
    }
}
