﻿namespace TMS_APP.Constants
{
    public class RoleD
    {
        public const string Role_Driver = "Driver";
        public const string Role_Admin = "Admin";
        public const string Role_Dispatcher = "Dispatch";
    }
}
