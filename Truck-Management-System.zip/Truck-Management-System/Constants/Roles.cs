﻿namespace TMS_APP.Constants
{
    public enum Roles
    {
        Driver,
        Dispatch,
        Admin       
    }
}
