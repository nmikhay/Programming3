﻿namespace Library.ViewModels
{
    public class BookDetailsViewModel
    {
        public int BookId { get; set; }
        public string BookTitle { get; set; }
        public string GenreName { get; set; }
        public string AuthorName { get; set; }
    }

}
