﻿namespace BookShop.Models
{
    public class Login
    {
    }
}
